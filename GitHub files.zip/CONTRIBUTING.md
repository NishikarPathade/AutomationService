# Contributing

Thank you for your interest in contributing to [NishikarPathade/AutomationService-Beginning](https://github.com/NishikarPathade/AutomationService-Beginning)!

- Add new vendor folders and sample programs
- Improve or add explanations, comments, and guides
- Submit links to helpful tutorials or videos
- Report issues or suggest improvements

**Guidelines:**
- Use clear folder and file names (e.g., `/Siemens/LadderLogic/StartStopMotor.ld`)
- Comment your code for educational purposes
- Provide references or links where possible
- Be respectful and collaborative

Fork the repo, make your changes, and submit a pull request.