# Mitsubishi PLC Samples

Example Ladder Logic programs for Mitsubishi PLCs (GX Works2).

- [LadderLogic/StartStopMotor.MEL](./LadderLogic/StartStopMotor.MEL): Classic Start/Stop Motor circuit.