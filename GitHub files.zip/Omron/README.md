# Omron PLC Samples

Example Ladder Logic programs for Omron PLCs (CX-Programmer, NJ/NX series).

- [LadderLogic/StartStopMotor.OMR](./LadderLogic/StartStopMotor.OMR): Classic Start/Stop Motor circuit.