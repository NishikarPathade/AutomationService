# Open Source PLC & SCADA

This folder contains guides and sample projects for open-source alternatives:

- [OpenPLC](https://www.openplcproject.com/)
- [ScadaBR](https://www.scadabr.com.br/?lang=en)
- [PLC Ladder Simulator](https://github.com/PLC-Ladder/PLC-Ladder-Simulator)

See subfolders for setup guides and example programs.