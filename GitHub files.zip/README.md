# Open Source PLC & SCADA Resource

A comprehensive, community-driven resource for PLC (Programmable Logic Controller) and SCADA (Supervisory Control and Data Acquisition) systems.

> **Repository:** [NishikarPathade/AutomationService-Beginning](https://github.com/NishikarPathade/AutomationService-Beginning)

## Features
- Explanations of PLC and SCADA concepts
- Sample programs for leading brands (Siemens, Allen-Bradley, Schneider, Mitsubishi, Delta, Omron)
- Guides for open-source PLC/SCADA software
- SCADA sample projects and guides
- Reference links and curated video tutorials

---

## Table of Contents
1. [What are PLC and SCADA?](#what-are-plc-and-scada)
2. [Major PLC & SCADA Companies](#major-plc--scada-companies)
3. [Programming Examples](#programming-examples)
    - [Siemens](./Siemens/)
    - [Allen-Bradley](./Allen-Bradley/)
    - [Schneider Electric](./Schneider/)
    - [Mitsubishi](./Mitsubishi/)
    - [Delta](./Delta/)
    - [Omron](./Omron/)
4. [Open Source PLC & SCADA](#open-source-plc--scada)
5. [SCADA Sample Projects](./SCADA/)
6. [Video Tutorials](#video-tutorials)
7. [References](#references)
8. [Contributing](#contributing)

---

## What are PLC and SCADA?

**PLC**: A ruggedized computer for industrial automation, controlling machinery, assembly lines, etc. Programs are written in Ladder Logic, Structured Text, or similar languages.

**SCADA**: A control system for high-level supervision, combining computers, networking, and GUIs for real-time monitoring and control of industrial processes.

---

## Major PLC & SCADA Companies

- **Siemens** — [Website](https://new.siemens.com/global/en/products/automation.html)
- **Allen-Bradley** (Rockwell Automation) — [Website](https://www.rockwellautomation.com/)
- **Schneider Electric** — [Website](https://www.se.com/)
- **Mitsubishi Electric** — [Website](https://www.mitsubishielectric.com/)
- **Delta Electronics** — [Website](https://www.delta.com.tw/)
- **Omron** — [Website](https://www.omron.com/)
- **ABB** — [Website](https://new.abb.com/)

---

## Programming Examples

Each vendor folder contains:
- A simple "Start/Stop Motor" example in their programming language (Ladder Logic, Structured Text, etc.)
- Program walkthroughs and comments

---

## Open Source PLC & SCADA

- [OpenPLC](https://www.openplcproject.com/) — Open source PLC with editor and runtime
- [ScadaBR](https://www.scadabr.com.br/?lang=en) — Open source SCADA system
- [PLC Ladder Simulator](https://github.com/PLC-Ladder/PLC-Ladder-Simulator) — Simulator for PLC ladder logic

See the [OpenSource](./OpenSource/) folder for setup guides and example projects.

---

## SCADA Sample Projects

- [SCADA Sample Projects & Guides](./SCADA/): Real-world examples, step-by-step walkthroughs, and learning resources for SCADA systems.

---

## Video Tutorials

- [What is a PLC? (RealPars)](https://www.youtube.com/watch?v=24CE5bhsfQk)
- [Siemens PLC Ladder Logic Example](https://www.youtube.com/watch?v=5bWSPlkHgrw)
- [Allen-Bradley PLC Basics](https://www.youtube.com/watch?v=Tr5XYnN6E2k)
- [OpenPLC Getting Started](https://www.youtube.com/watch?v=Qh3vJc7y0L8)
- [What is SCADA?](https://www.youtube.com/watch?v=1x3aA3B1cXY)

---

## References

- [PLC Programming - InstrumentationTools](https://instrumentationtools.com/plc-programming/)
- [SCADA Fundamentals - Inductive Automation](https://inductiveautomation.com/resources/article/what-is-scada)
- [IEC 61131-3 Programming Languages](https://en.wikipedia.org/wiki/IEC_61131-3)

---

## Contributing

PRs with new examples, guides, or corrections are welcome!  
See [CONTRIBUTING.md](./CONTRIBUTING.md) for guidelines.

---

*This is an open source project. You are free to use, share, and contribute!*