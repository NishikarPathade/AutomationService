# SCADA Sample Projects

This folder contains guides and sample projects for learning SCADA (Supervisory Control and Data Acquisition) systems, including integration with PLCs.

- [SCADA_Sample_Project.md](./SCADA_Sample_Project.md): Complete walkthrough of a typical SCADA automation project for water tank monitoring and control, with PLC integration and HMI screens.
- [links.md](./links.md): Curated tutorials, video demos, and documentation for multiple SCADA platforms.

---

## Typical SCADA Software Platforms

- **Siemens WinCC**
- **Wonderware (AVEVA) InTouch**
- **Schneider Electric Vijeo Citect**
- **Ignition (Inductive Automation)**
- **FactoryTalk View (Rockwell Automation)**
- **Open Source: ScadaBR, OpenSCADA**

---

## Sample Project: Water Tank Monitoring & Control

See [SCADA_Sample_Project.md](./SCADA_Sample_Project.md) for a full example, including:
- System overview and requirements
- PLC and HMI/SCADA configuration
- Screenshots/mockups
- Typical tag list and alarms

---

## More Resources

Check [links.md](./links.md) for step-by-step video tutorials and official documentation for various SCADA systems.