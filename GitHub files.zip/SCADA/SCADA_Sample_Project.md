# SCADA Sample Project: Water Tank Monitoring & Control

## 1. Project Overview

**Objective:**  
Design a SCADA system to monitor and control a simple water tank using a PLC. Operators should be able to view tank levels, start/stop a pump, and receive alarms for high/low water levels.

---

## 2. System Components

- **PLC**: Handles inputs (level sensors), outputs (pump relay), and communicates with SCADA.
- **SCADA/HMI**: Visualizes tank status, allows manual control, and logs alarms/events.
- **Sensors/Actuators**:
    - Level Switches (Low/High)
    - Pump Motor (ON/OFF)

---

## 3. PLC Program (Example Logic)

- **Inputs**:
    - I0.0: Low Level Switch (1 = water above low)
    - I0.1: High Level Switch (1 = water above high)
    - I0.2: Manual Start (from SCADA)
    - I0.3: Manual Stop (from SCADA)

- **Outputs**:
    - Q0.0: Pump Motor

**Logic:**
- Start pump if level is low and not high, or if manual start is pressed.
- Stop pump if high level is reached, or manual stop is pressed.

---

## 4. SCADA/HMI Configuration

- **Tags to Read/Write:**
    - Tank_Low_Level (digital input)
    - Tank_High_Level (digital input)
    - Pump_Status (digital output)
    - Pump_Start_Cmd (digital output)
    - Pump_Stop_Cmd (digital output)

- **Screens/Objects:**
    - Tank graphic with animated level
    - Pump symbol (running/not running)
    - Start/Stop buttons
    - Alarm indicators ("Low Level!", "High Level!")

---

## 5. Example HMI Screen Layout

```
+------------------------------------------+
|           WATER TANK CONTROL             |
+------------------------------------------+
|   [ Tank Level   ]        [Pump: ON/OFF] |
|   [   Graphics   ]  [Start] [Stop]       |
|                                          |
|   [ Alarms: ]                            |
|   - Low Level!                           |
|   - High Level!                          |
+------------------------------------------+
```

---

## 6. Communication

- **PLC-SCADA Protocols:**  
  - Modbus TCP, OPC UA, PROFINET, EtherNet/IP (depends on PLC/SCADA)

- **Typical Tag Mapping Example (Modbus):**
    - 00001: Low Level Switch
    - 00002: High Level Switch
    - 00003: Pump Status
    - 00004: Pump Start Command
    - 00005: Pump Stop Command

---

## 7. Alarming & Logging

- SCADA alarms on high/low tank level
- Event log for pump starts/stops

---

## 8. Further Steps

- Add trending for tank level
- Historical data logging
- Remote notification (email/SMS on alarm)
- Multi-tank or pump expansion

---

## 9. References & Tutorials

See [links.md](./links.md) for detailed, step-by-step video guides for this and similar projects on multiple SCADA platforms.