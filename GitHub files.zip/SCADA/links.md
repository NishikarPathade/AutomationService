# SCADA Learning Resources & Tutorials

## General SCADA Concepts

- [What is SCADA? (YouTube, RealPars)](https://www.youtube.com/watch?v=1x3aA3B1cXY)
- [SCADA Explained (PLC Professor)](https://www.youtube.com/watch?v=LPyH1b8J3jA)

## Water Tank SCADA Project Tutorials

- [WinCC (Siemens) Water Tank Project Example](https://www.youtube.com/watch?v=QXJrK4f9nVw)
- [Ignition SCADA Water Tank Demo](https://www.youtube.com/watch?v=8wdsA0k0WJQ)
- [Wonderware InTouch Water Tank Tutorial](https://www.youtube.com/watch?v=6O89e1X9L2o)
- [Open Source: ScadaBR Water Tank Simulation](https://www.youtube.com/watch?v=VQj6Q1k8cUo)

## SCADA Platform Official Documentation

- [Siemens WinCC Documentation](https://support.industry.siemens.com/cs/document/109755202/)
- [AVEVA InTouch (Wonderware)](https://www.aveva.com/en/products/hmi-supervisory-and-control/intouch-hmi/)
- [Ignition by Inductive Automation](https://docs.inductiveautomation.com/)
- [Schneider Electric Citect SCADA](https://www.se.com/ww/en/product-range/62053-citect-scada/)
- [ScadaBR Open Source](https://www.scadabr.com.br/?lang=en)