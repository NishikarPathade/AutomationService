# Schneider Electric PLC Samples

Example Ladder Logic programs for Schneider Electric PLCs (Modicon, EcoStruxure Control Expert).

- [LadderLogic/StartStopMotor.STU](./LadderLogic/StartStopMotor.STU): Classic Start/Stop Motor circuit.