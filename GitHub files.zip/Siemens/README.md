# Siemens PLC Samples

Example Ladder Logic and Structured Text programs for Siemens PLCs (SIMATIC S7 series, TIA Portal).

- [LadderLogic/StartStopMotor.ld](./LadderLogic/StartStopMotor.ld): Classic Start/Stop Motor circuit.